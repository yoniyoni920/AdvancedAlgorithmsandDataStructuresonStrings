Yuval Shahar 209455112
Yoni Grinberg 307868257
Due to the extensive volume of data generated, the console output in the command prompt is truncated. To review the complete set of results, please refer to the output.txt file
### Requirements
- Python 3.8 or higher
- No external dependencies (only built-in libraries: `sys`)

