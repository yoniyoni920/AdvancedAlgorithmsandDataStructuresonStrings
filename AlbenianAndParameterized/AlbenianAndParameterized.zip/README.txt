Yuval Shahar 209455112
Yoni Grinberg 307868257
### Requirements
- Python 3.8 or higher
- No external dependencies (only built-in libraries: `random`, `os`, `time`)