
def compute_parent_distance(seq):
    stack = []
    pd = [0] * len(seq)
    for i, val in enumerate(seq):
        while stack and seq[stack[-1]] > val:
            stack.pop()
        if stack:
            pd[i] = i - stack[-1]
        else:
            pd[i] = 0
        stack.append(i)
    return pd





def cartesian_tree_match(text, L, k):
    """
        Find recurring motifs in a sequence using Cartesian Tree Matching (CTM).

        Args:
            text (list[int]): The input sequence of integers.
            L (int): Window length to extract motifs.
            k (int): Minimum number of occurrences for a motif to be considered recurring.

        Returns:
            list[tuple]: List of recurring motifs, each as (PD_tuple, (count, positions, windows))
                         - PD_tuple: tuple representing the parent-distance array of the motif
                         - count: number of occurrences
                         - positions: starting indices of occurrences
                         - windows: actual sublists corresponding to the motif
        """
    n = len(text)
    motifs = {}
    for i in range(n - L + 1):
        window = text[i:i+L]
        PD_window = tuple(compute_parent_distance(window))
        if PD_window in motifs:
            count, positions, windows = motifs[PD_window]
            motifs[PD_window] = (count + 1, positions + [i], windows + [window])
        else:
            motifs[PD_window] = (1, [i], [window])
    recurring = [(pd, (count, pos, win)) for pd, (count, pos, win) in motifs.items() if count >= k]
    return recurring